
-----------------------DAY 5 Assignments-------------------
-- 1.	Write a procedure to insert data in Patient and PatientAddress tables using input parameters 
-- [PatientID is an Identity column in Patient table and PatientAddress table is related to Patient table]

CREATE TABLE Patient
(
PatientID INT PRIMARY KEY,
PatientName VARCHAR(20),
Gender VARCHAR(1),
);
 
CREATE TABLE PatientAddress
(
PatientID INT REFERENCES Patient(PatientID) ,
P_Address VARCHAR(50)
);
DROP PROCEDURE PRO
CREATE PROCEDURE PRO
(
@PatientID INT,
@PatientName VARCHAR(20),
@Gender VARCHAR(1),
@P_Address VARCHAR(50)
)
AS
BEGIN
    INSERT INTO Patient_table VALUES (@PatientID,@PatientName,@Gender)
    PRINT 'PATIENT RECORDS INSERTED...'

   INSERT INTO PatientAddress VALUES (@PatientID,@P_Address)
    PRINT 'PATIENT ADDRESS INSERTED...'
END

EXECUTE dbo.PRO 1,'Tarun','M','Hyderabad';
EXECUTE dbo.PRO 2,'Sanath','M','Jammu';
EXECUTE dbo.PRO 3,'Prasanna','F','Banglore';

SELECT * FROM Patient
SELECT * FROM PatientAddress

------------------------------------------------------------------------------------------
/* 2.An input string representing passenger data comes in a below format to a procedure. Extract the data from the string 
and store in a temporary table. String format: �[P9001,John Roy,Male,12-Jan-2009]�*/

create table #temp
(
ID varchar(10),
name varchar(15),
gender varchar(10),
dob varchar(15) 
)

create procedure STRING
(
@String varchar(50),
@ID varchar(10)=null,
@Name varchar(10)=null,
@gender varchar(10)=null,
@birthdate varchar(15)=null
)as
begin
set @ID =substring(@String,0,PATINDEX('%,%',@String))
set @String =substring(@String,len(@ID+',')+1,len(@String))

set @Name =substring(@String,0,PATINDEX('%,%',@String))
set @String =substring(@String,len(@Name+',')+1,len(@String))

set @gender =substring(@String,0,PATINDEX('%,%',@String))
set @String =substring(@String,len(@gender+',')+1,len(@String))

set @birthdate=@String

insert into #temp(ID,name,gender,dob) values (@ID,@Name,@gender,@birthdate)

select * from #temp
PRINT @ID;
PRINT @Name;
PRINT @gender;
PRINT @birthdate;
print 'inserted!'
end;

Execute STRING 'P9001,John Roy,Male,12-Jan-2009';

---------------------------------------------------------------------------------------------------------
/*3.Modify the Day 5 - Lab 2 to validate the below
   1.No duplicate entry for a passenger must be attempted to insert in table
   2.The Age of the passenger must be between 6 to 90 */

create table #Temp1
(
ID varchar(10) PRIMARY KEY,
name varchar(15),
gender varchar(10),
dob DATE check( YEAR(GETDATE())  - year(dob) between 6 and 90)  
)
SELECT * FROM #Temp1

create procedure passenger1
(
@String varchar(50),
@ID varchar(10)=null,
@Name varchar(10)=null,
@gender varchar(10)=null,
@birthdate varchar(15)=null
)as
begin
set @ID =substring(@String,0,PATINDEX('%,%',@String))
set @String =substring(@String,len(@ID+',')+1,len(@String))

set @Name =substring(@String,0,PATINDEX('%,%',@String))
set @String =substring(@String,len(@Name+',')+1,len(@String))

set @gender =substring(@String,0,PATINDEX('%,%',@String))
set @String =substring(@String,len(@gender+',')+1,len(@String))

set @birthdate=@String

insert into #Temp1(ID,name,gender,dob) values (@ID,@Name,@gender,@birthdate)

select * from #Tab
PRINT @ID;
PRINT @Name;
PRINT @gender;
PRINT @birthdate;
print 'inserted!'
end;

execute passenger1'P9001,John Roy,Male,12-Jan-2009';
execute passenger1'P9002,mary,female,15-nov-2008';

