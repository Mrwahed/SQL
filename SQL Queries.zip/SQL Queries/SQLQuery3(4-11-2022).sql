SELECT Color, SUM(StandardCost) AS [TotalCost],
COUNT(*) AS [Count]
FROM Production.Product
GROUP BY Color
HAVING COUNT(*) >40

SELECT  MAX (BirthDate),Gender FROM HumanResources.Employee
GROUP BY Gender

SELECT Color, SUM(StandardCost) AS [TotalCost],
COUNT(*) AS [Count]
FROM Production.Product
GROUP BY Color





SELECT *,
COUNT(*)OVER(PARTITION BY Gender) AS [TotalCost]
FROM HumanResources.Employee

SELECT *,
DENSE_RANK()OVER(ORDER BY HireDate ASC) AS [D_RNK]
FROM HumanResources.Employee

SELECT ProductID,Name,Color,StandardCost,
DENSE_RANK() OVER(ORDER BY StandardCost DESC) AS [D_RNK]
FROM Production.Product