
  create table Departments(

   DepartmentId INT PRIMARY KEY,
   Name NVARCHAR(30) NOT NULL
   )

   create table Employees(

   EmployeeId INT IDENTITY(1001,1) PRIMARY KEY,
   FirstName NVARCHAR(20) NOT NULL,
   LastName NVARCHAR(20) NOT NULL,
   Salary DECIMAL(10,3) NOT NULL,
   DepartmentId INT  References   Departments(DepartmentId)
   
   )




