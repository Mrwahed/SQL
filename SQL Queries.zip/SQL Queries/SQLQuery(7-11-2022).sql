SELECT EMP.BusinessEntityID,EMP.JobTitle,EMP.HireDate,EMP.BirthDate,EMP.Gender,EMP.MaritalStatus,
PER.BusinessEntityID,PER.FirstName,PER.LastName
FROM HumanResources.Employee AS EMP
JOIN
Person.Person AS PER
ON EMP.BusinessEntityID = PER.BusinessEntityID

SELECT E.BusinessEntityID,E.JobTitle,
P.BusinessEntityID,P.FirstName,P.LastName
FROM HumanResources.Employee AS E
 RIGHT OUTER JOIN
Person.Person AS P
ON E.BusinessEntityID = P.BusinessEntityID
------------------------------------------------------------
 SELECT P.ProductID,P.ProductSubcategoryID
 FROM Production.Product AS P
RIGHT OUTER JOIN

Production.ProductSubcategory AS PSC
ON P.ProductSubcategoryID = PSC.ProductSubcategoryID

---------------------------------------------------------------------
--get the order details with productid that are part of order
SELECT SOH.SalesOrderID,SOH.OrderDate,SOH.CustomerID,SOH.SalesPersonID,SOH.TerritoryID, SOD.ProductID,SOD.OrderQty

FROM Sales.SalesOrderHeader AS SOH
JOIN
Sales.SalesOrderDetail AS SOD 
ON SOH.SalesOrderID = SOD.SalesOrderID

------------------------------------------------------------------------

SELECT SOH.SalesOrderID, SOH.OrderDate,SOH.CustomerID,
SOH.SalesPersonID,SOH.TerritoryID,SOD.ProductID,
PRD.Name AS [ProdName], PSC.Name AS [Sub Catg.], PCT.Name AS [Catg.], SC.CustomerID,PP.BusinessEntityID,
TRT.TerritoryID,SOD.OrderQty
FROM Sales.SalesOrderHeader SOH INNER JOIN Sales.SalesOrderDetail SOD
ON SOH.SalesOrderID = SOD.SalesOrderID
INNER JOIN Production.Product PRD
ON SOD.ProductID = PRD.ProductID
LEFT OUTER JOIN Production.ProductSubcategory PSC
ON PSC.ProductSubcategoryID = PRD.ProductSubcategoryID
LEFT OUTER JOIN Production.ProductCategory PCT
ON PSC.ProductCategoryID = PCT.ProductCategoryID
JOIN Sales.Customer SC
ON SOH.CustomerID = SC.CustomerID
JOIN Person.Person PP
ON SC.PersonID = PP.BusinessEntityID
JOIN Sales.SalesTerritory TRT
ON SOH.TerritoryID = TRT.TerritoryID
--------------------------------------------------