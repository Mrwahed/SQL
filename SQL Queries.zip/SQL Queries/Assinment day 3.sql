
----1----
SELECT COUNT(*) AS Customers
 FROM Sales.Customer

 ------2------
SELECT MAX(ListPrice) AS maximum,MIN(ListPrice) AS minimum, AVG(ListPrice) AS average
FROM Production.Product

-----3--------
SELECT ProductID,OrderQty
FROM Sales.SalesOrderDetail
GROUP BY ProductID,OrderQty

--------4------
SELECT SalesOrderID,COUNT(SalesOrderID) AS [EachLINE]
FROM Sales.SalesOrderDetail
GROUP BY SalesOrderID

-----5--------
SELECT ProductLine,COUNT(ProductID) AS [prod count]
FROM Production.Product
GROUP BY ProductLine

-------6-----
SELECT COUNT(YEAR(OrderDate)) AS COUNTOFORDERS, YEAR(OrderDate) AS OrderYear,CustomerID
FROM Sales.SalesOrderHeader
GROUP BY YEAR(OrderDate),CustomerID

-------7-------
SELECT SalesOrderID,SUM(LineTotal) AS SL
FROM Sales.SalesOrderDetail
GROUP BY SalesOrderID
HAVING SUM(LineTotal)>1000

------8-----
SELECT ProductModelID,COUNT(ProductID) as [NO OF PROD]
FROM Production.Product
GROUP BY ProductModelID
HAVING COUNT(ProductID) = 1

-----9-------
SELECT PP.ProductID, SUM(OrderQty) AS SumOfOrder, SOH.OrderDate
FROM Sales.SalesOrderHeader AS SOH JOIN Sales.SalesOrderDetail AS SOD
ON SOH.SalesOrderID = SOD.SalesOrderID
INNER JOIN Production.Product AS PP
ON PP.ProductID = SOD.ProductID
GROUP BY PP.ProductID, SOH.OrderDate

------10---
SELECT * FROM
(
SELECT HS.BusinessEntityID,HireDate,MaritalStatus,Gender,
DENSE_RANK() OVER(ORDER BY HireDate) AS DRNK
FROM HumanResources.Employee as HS JOIN Person.Person AS PP
ON HS.BusinessEntityID  = PP.BusinessEntityID
)AS t WHERE DRNK=3;

-----11----
SELECT * FROM
(
  SELECT CustomerID,COUNT(customerid) AS [Orders] ,
  Dense_Rank()OVER(ORDER BY COUNT(customerid) DESC) AS [RANK]
  FROM Sales.SalesOrderHeader
  GROUP BY CustomerID
)W WHERE [RANK] =2

----12-----
SELECT * FROM
(
SELECT ProductID,PSC.ProductSubcategoryID,PSC.Name,StandardCost,
NTILE(4)OVER(PARTITION BY PSC.Name ORDER BY standardcost DESC) AS [costliest item rank]
FROM Production.Product AS [PP]
join
Production.ProductSubcategory AS [PSC]
ON PP.ProductSubcategoryID = PSC.ProductSubcategoryID
)t
WHERE[costliest item rank] = 1

-----13----

CREATE TABLE cessnab2Employee
(
  EmpID INT,
  Name VARCHAR(20)

)

CREATE TABLE cessnab2Customer
(
CustID INT,
Name VARCHAR(20)
)

CREATE SEQUENCE cessnab2_sequence AS INT
START WITH 1001
INCREMENT BY 3
MAXVALUE 5000
MINVALUE 10
NO CYCLE
CACHE 25

INSERT INTO cessnab2Employee Values
(Next VALUE FOR cessnab2_sequence, 'wahed')
INSERT INTO cessnab2Employee Values
(Next VALUE FOR cessnab2_sequence, 'sanath')
INSERT INTO cessnab2Employee Values
(Next VALUE FOR cessnab2_sequence, 'tarun')
INSERT INTO cessnab2Employee Values
(Next VALUE FOR cessnab2_sequence, 'nanji')

SELECT * FROM cessnab2Employee

INSERT INTO cessnab2Customer Values
(Next VALUE FOR cessnab2_sequence, 'jhon')
INSERT INTO cessnab2Customer Values
(Next VALUE FOR cessnab2_sequence, 'majji')
INSERT INTO cessnab2Customer Values
(Next VALUE FOR cessnab2_sequence, 'hannah')
INSERT INTO cessnab2Customer Values
(Next VALUE FOR cessnab2_sequence, 'clay')

SELECT * FROM cessnab2Customer







