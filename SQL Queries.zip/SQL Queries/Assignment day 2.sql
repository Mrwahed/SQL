-----------------------------DAY 2 ASSIGNMENTS-------------------
----1----
SELECT BusinessEntityID,FirstName,ModifiedDate    
FROM Person.Person WHERE ModifiedDate > '2009'
---2-----
SELECT BusinessEntityID, FirstName, MiddleName, LastName, ModifiedDate
FROM Person.Person
WHERE ModifiedDate  NOT BETWEEN '2000-12-01' AND '2000-12-31';

-----3-----
SELECT ProductID,Name
FROM Production.Product WHERE Name like 'Chain%'
----4-----
SELECT BusinessEntityID,FirstName,MiddleName,LastName
FROM Person.Person WHERE MiddleName like 'E' or MiddleName like 'B'

------5-----
SELECT SalesOrderID,OrderDate,TotalDue
FROM sales.SalesOrderHeader WHERE OrderDate > '2001-09-01' and TotalDue >'$1000'
----6----
SELECT SalesPersonID,TerritoryID,TotalDue
FROM Sales.SalesOrderHeader WHERE TotalDue>'$1000' and SalesPersonID = '279' or TerritoryID='6'
---7---
SELECT ProductID,Name,Color
FROM Production.Product WHERE Color <> 'BLUE'
----8---
SELECT BusinessEntityID,FirstName,MiddleName,LastName
FROM Person.Person ORDER BY FirstName,MiddleName,LastName
----9-----
SELECT AddressLine1 + '('+City+' '' '+Postalcode+')' AS [address]
From Person.Address

----10----
SELECT ProductID,ISNULL(Color,'No Color') AS Color,Name
FROM Production.Product
----11---
SELECT ProductID,Name,ISNULL(':' +color,+'') AS [Description]
FROM Production.Product
---12---
SELECT SpecialOfferID,MinQty,MaxQty,Description,
MaxQty-MinQty as DIFFERENCE
FROM Sales.SpecialOffer
----13---
SELECT SpecialOfferID,ISNULL(MaxQty,10),DiscountPct,MaxQty*DiscountPct as MULTIPLICATION
FROM Sales.SpecialOffer
---14---
SELECT SUBSTRING(AddressLine1,1,10)
FROM Person.Address
----15---
SELECT SalesOrderID,OrderDate,ShipDate,DATEDIFF(dd,OrderDate,ShipDate) as [No.Of Days]
FROM Sales.SalesOrderHeader
----16-----
SELECT CONVERT(VARCHAR,OrderDate,1) AS OrderDate,
CONVERT(VARCHAR,ShipDate,1) AS ShipDate
FROM Sales.SalesOrderHeader
-----17------
SELECT SalesOrderID,OrderDate,DATEADD(m,6,OrderDate) [after6 months]
FROM Sales.SalesOrderHeader
-------18------
SELECT SalesOrderID,OrderDate ,YEAR(OrderDate) AS [Year],MONTH(OrderDate) AS[Month]
FROM Sales.SalesOrderHeader
-------19------
SELECT ceiling(rand()*10) as [random number]
----20----
SELECT SalesOrderID,OrderDate
FROM Sales.SalesOrderHeader WHERE YEAR(OrderDate) ='2012'
-----21-----
select SalesOrderID,month(OrderDate) as [month],year(OrderDate) as [year],OrderDate
from Sales.SalesOrderHeader
order by month(orderdate),year(orderdate)
