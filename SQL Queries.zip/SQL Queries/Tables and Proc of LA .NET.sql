drop table customers
create table customers(
    customerid int primary key,--constraint pk_custid primary key,
    customername varchar(30),
    city varchar(20),
    state varchar(20),
    email varchar(30)
)

Drop proc InsertCustomer
create proc InsertCustomer
@cid int,
@cname varchar(30),
@customercity varchar(30),
@customerstate varchar(30),
@email varchar(20)
as
    insert into customers values(@cid,@cname,@customercity,@customerstate,@email)



drop table Account
 create table Account(
      AccountId  int  ,
      AccountType int ,
	  Balance int,
	  customerid int REFERENCES customers(customerid) ,
  )

  drop proc InsertAccount
  create proc InsertAccount
  @accid int,
  @acctype int,
  @balance int,
  @cid int
  as 
   insert into Account values(@accid,@acctype,@balance,@cid)
