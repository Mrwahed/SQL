DROP TAble Account
 create table Account(
      AccountId  int  ,
      AccountType int ,
	  Balance int,
	  
	  customerid int FOREIGN KEY REFERENCES customers(customerid) ,
  )
  
create proc InsertAccount

@AccountId int,
@AccountType int,
@Balance int,
@customerid int,

AS
    insert into customers values(AccountId,AccountType,@Balance,@customerid)