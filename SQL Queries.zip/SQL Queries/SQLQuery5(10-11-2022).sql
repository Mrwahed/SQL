DROP TABLE Cessnatrainee
CREATE TABLE Cessnatrainee
(
TrainingID INT,
FirstName VARCHAR(20),
LastName VARCHAR(20),
Gender VARCHAR(1),
BatchNo INT,
RandomCode INT
);

SELECT * FROM Cessnatrainee
CREATE PROCEDURE SP
(
@TrainingID INT,
@FirstName VARCHAR(20),
@LastName VARCHAR(20),
@Gender VARCHAR(1),
@BatchNo INT,
@RandomCode INT
)AS
BEGIN
	IF @FirstName IS NOT NULL AND @LastName IS NOT NULL AND @Gender IN('M','F') AND @BatchNo IN(1,2) AND @RandomCode BETWEEN 1 AND 10
		BEGIN
		INSERT INTO Cessnatrainee VALUES
			(@TrainingID,@FirstName,@LastName,@Gender,@BatchNo,@RandomCode);
			 PRINT 'Record Inserted!';
		END;
	ELSE
      PRINT 'Record Not inserted';

END ;

EXECUTE dbo.SP 14979,'wahed','ali','M',2,4;
------------------------------------------------------------

--DEMO 1:
CREATE FUNCTION udf_add_two_numbers(@Num1 INT, @Num2 INT)RETURNS INT
AS
BEGIN
    DECLARE @SUM INT;
    SET @SUM = @Num1 + @Num2;
    RETURN @SUM;
END;



PRINT dbo.udf_add_two_numbers (100,200)
--OR
SELECT dbo.udf_add_two_numbers (100,200)

------------------------------------
/*
Lab:
CREATE a funct that takes businessentityid as parameter
and returns fullname of a person
*/

CREATE FUNCTION person_details(@businessentityid INT,@FirstName VARCHAR(20),@LastName VARCHAR(20)) RETURN VARCHAR
  AS
BEGIN 
  DECLARE @businessentityid INT;
  SET @businessentityid = @FirstName + @LastName 
  RETURN @businessentityid;

  END;

  PRINT dbo.person_details(101,'wahed','ali')
  SELECT dbo.person_details(101,'wahed','ali')




