
create proc InsertCustomer
@cid int,
@cname varchar(30),
@customercity varchar(30),
@customerstate varchar(30),
@email varchar(20)
as
    insert into customers values(@cid,@cname,@customercity,@customerstate,@email)