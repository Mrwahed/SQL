/*
CURSORS 
    --IMPLICIT
	--EXPLICIT
*/

--DEMO:: EXPLICT CURSOR
/*
DECLARE @ProdID INT;
DECLARE @ProdName VARCHAR(50);
DECLARE @Color VARCHAR(20);
DECLARE cur_cessna_sleeping_pax CURSOR
    FOR  SELECT ProdID,ProdName,Color FROM BlackProducts;
OPEN cur_cessna_sleeping_pax;
--PRINT @@FETCH_STATUS;
FETCH NEXT FROM cur_cessna_sleeping_pax
    INTO @ProdID,@ProdName,@Color;
WHILE @@FETCH_STATUS = 0
BEGIN
    PRINT '----------------------------------------------------------------';
    PRINT CONCAT('Product ID: ',@ProdID);
    PRINT CONCAT('Product Name: ',@ProdName);
    PRINT CONCAT('Color: ',@Color);
    PRINT '----------------------------------------------------------------';
    FETCH NEXT FROM cur_cessna_sleeping_pax
        INTO @ProdID,@ProdName,@Color;
END
CLOSE cur_cessna_sleeping_pax;
DEALLOCATE cur_cessna_sleeping_pax;
*/
----------------------------------------------------------------------------------------------

--demo 2 excercise
DECLARE @productID INT;
DECLARE @Name VARCHAR(50);
DECLARE @color VARCHAR(50);
DECLARE cur_productdetails_pax CURSOR
    FOR  SELECT ProductID,Name,Color FROM Production.Product;
OPEN cur_productdetails_pax;
--PRINT @@FETCH_STATUS;
FETCH NEXT FROM cur_productdetails_pax
    INTO @ProductID,@Name,@Color;
WHILE @@FETCH_STATUS = 0
BEGIN
    PRINT '----------------------------------------------------------------';
    PRINT CONCAT('Product ID: ',@ProductID);
    PRINT CONCAT(' Name: ',@Name);
    PRINT CONCAT('Color: ',@color);
    PRINT '----------------------------------------------------------------';
    FETCH NEXT FROM cur_productdetails_pax
        INTO @ProductID,@Name,@color;
END
CLOSE cur_productdetails_pax;
DEALLOCATE cur_productdetails_pax;


--------------------------------------------------------------------------------------------------

BEGIN TRY
    PRINT 'TRY STARTED!';
    INSERT INTO PatientAdministration.Patient
        (PatientName,DOB,Gender,ContactNo)VALUES
        ('Mahesh','1988-01-01','J','88XXXXXX90');
    PRINT 'TRY ENDED!';
END TRY
BEGIN CATCH
    --PRINT 'Something Went Wrong!';
    PRINT ERROR_NUMBER();
    PRINT ERROR_MESSAGE();
END CATCH

-------------------------------------------------------------------------------

CREATE TABLE TestTable
(
  TestID INT PRIMARY KEY,
  TestName VARCHAR(50),
  TestDate DATE,
  TestType VARCHAR(1)CHECK(TestType IN ('D', 'P', 'T'))
)

BEGIN TRY
    PRINT 'TRY STARTED!';
    INSERT INTO TestTable
        (TestID,TestName,TestDate,TestType)VALUES
        ('10','GIT-test','2022-01-01','{D,P,T}');
    PRINT 'TRY ENDED!';
END TRY
BEGIN CATCH
    --PRINT 'Something Went Wrong!';
    --PRINT ERROR_NUMBER();
    --PRINT ERROR_MESSAGE();

	IF ERROR_NUMBER() = 245
	  PRINT 'converstion failed from string to int';
	IF ERROR_NUMBER() =8134
	    PRINT'Divide by zero';
	ELSE 
	PRINT 'OTHER ERROR'
END CATCH
