
-------------SEQUENCE:USED TO GENERATE SEQUENTIAL NUMBERS------

CREATE SEQUENCE cessna_batch2_seq AS INT
START WITH 100
INCREMENT BY 5
MAXVALUE 5000
MINVALUE 10
NO CYCLE
CACHE 25 

SELECT NEXT VALUE FOR  cessna_batch2_seq


CREATE TABLE cb2Employee
(
	EmpID INT,
	EmpName VARCHAR(20)
);
INSERT INTO cb2Employee VALUES (101,'Gary')
INSERT INTO cb2Employee VALUES (102,'harry')
INSERT INTO cb2Employee VALUES (103,'clay')

CREATE TABLE cb2Customer
(
     CustomerID INT,
	 CustomerName VARCHAR(20)
);
INSERT INTO cb2Customer VALUES (1,'Warner')
INSERT INTO cb2Customer VALUES (2,'david')
INSERT INTO cb2customer VALUES (3,'dhoni')

SELECT * FROM cb2Employee
SELECT * FROM cb2Customer



DROP SEQUENCE cb2Emp 
CREATE SEQUENCE cb2Emp AS INT
START WITH 1
INCREMENT BY 1
MAXVALUE 5
MINVALUE 1
NO CYCLE
CACHE 25 

INSERT INTO cb2Employee VALUES
(NEXT VALUE FOR cb2Emp,'104','tarun')


------------------------------------------------------------------------------------------
--Demo 1:Anonyms Block:Working with variable
/*DECLARE @UserName VARCHAR(50);
SET @UserName = 'Hey john';
SELECT @UserName;
PRINT @UserName;

--Demo 2:Anonyms Block:Working with variable to get data from table
DECLARE @BussEntID INT;
DECLARE @FName VARCHAR(50);
DECLARE @LName VARCHAR(50);
SET @BussEntID = 5;
SELECT @FName=FirstName, @LName= LastName
FROM Person.Person WHERE BusinessEntityID = @BussEntID;

PRINT '--------------------------------------';
PRINT 'BUSINESS ENTITY ID: '+ CONVERT(VARCHAR(20), @BussEntID) ;
PRINT 'FIRST NAME: '+ @FName;
PRINT 'LAST NAME: '+ @LName;
PRINT '--------------------------------------';*/

/*
Lab::: Get name and jobtitle of an employee in variable and display the variable values for businessentityid 5
*/

DECLARE @BussEntID INT;
DECLARE @FName VARCHAR(50);
DECLARE @LName VARCHAR(50);
DECLARE @JobTitle VARCHAR(20);
SET @BussEntID = 5;
SELECT @FName=FirstName, @LName= LastName

FROM HumanResources.Employee AS HRE
INNER JOIN
Person.Person AS PP
ON HRE.BusinessEntityID = pp.BusinessEntityID 
 WHERE HRE.BusinessEntityID = @BussEntID;

 
PRINT '--------------------------------------';
PRINT 'BUSINESS ENTITY ID: '+ CONVERT(VARCHAR(20), @BussEntID) ;
PRINT 'FIRST NAME: '+ @FName;
PRINT 'LAST NAME: '+ @LName;
PRINT '--------------------------------------';

----------------------------------------------------------------------------------
--DEMO 3:: Ananymous block :: If statement
DECLARE @PatientName VARCHAR(20);
DECLARE @IsDeceased VARCHAR(10);
SET @PatientName = 'MAJJI TARUN';
SET @IsDeceased = 'yes';
IF UPPER(@IsDeceased) = 'YES'
BEGIN --begin-end to be written in case of multiple statements
   PRINT 'service cannot be granted to deceased patient named '+@patientName+'!';
   END;
ELSE
   PRINT 'Welcome to the hospital! MAJJI';

--DEMO 4::Anonymous Block::iF else if statement
/*age <0 and >100 is inval
IF AGE IS VALID
age is between 0 to 12::: child
age is between 13 to 20 :: teen
age is between 21 to 50 :: Adult 
age is 50 to 100 :: senior citizen*/

DECLARE @Age INT;
SET @Age = 56;
IF @Age<0 OR @Age>100
    PRINT 'INVALID AGE!';
ELSE
BEGIN
    PRINT 'VALID AGE!';
    IF @Age >= 0 AND @Age <= 12
        PRINT 'Child.';
    ELSE IF @Age >= 13 AND @Age <= 20
        PRINT 'Teen.';
    ELSE IF @Age >= 21 AND @Age <= 50
        PRINT 'Adult.';
    ELSE IF @Age >= 51 AND @Age <= 100
        PRINT 'Sr. Citizen';
END;

/*
  Declare 5 variables to represent marks of 5 subjects (out of 100;passing is 40).
  calculate total and percentage only if a student is passed.
  Display marks of all subjects for failed students with message as FAIL and
  Display marks,total and percentage for passed students message as PASS
  */

DECLARE @Maths INT;
DECLARE @Physics INT;
DECLARE @English INT;
DECLARE @Hindi INT;
DECLARE @Social INT;
DECLARE @Total INT;
DECLARE @Percentage FLOAT;

SET @Maths = 95;
SET @Physics = 50;
SET @English = 66;
SET @Hindi = 98;
SET @Social = 33;
SET @Total=SUM(@Maths + @Physics + @English + @Hindi+ @Social);

IF @Maths<=40 AND @English<=40 AND @Physics<=40 AND @Hindi<=40 AND @Social<=40
PRINT 'FAIL';
ELSE 
BEGIN 


