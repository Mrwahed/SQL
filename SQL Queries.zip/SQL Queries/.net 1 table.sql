
 create table Customers(
      CustomerId int,
      CustomerName varchar,
	  CustomerCity varchar,
	  CustomerState varchar,
    )