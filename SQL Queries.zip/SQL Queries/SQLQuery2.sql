CREATE TABLE Employee
(
EmpId INT PRIMARY KEY IDENTITY(101,1),
EmpName VARCHAR(20) NOT NULL,
Gender VARCHAR(1) CHECK(Gender IN('M','F','O','U')),
HireDate DATE CHECK(HireDate < GETDATE()) NOT NULL,
City VARCHAR(20) DEFAULT 'Mumbai'
);

INSERT INTO Employee
VALUES('Sanath','M','11-Jan-2020','Hyderabad')



SELECT * FROM Employee