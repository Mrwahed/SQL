/*UDFs-USER DEFINED FUNCTIONS*/
--Demo--check if a string is palindrome
CREATE FUNCTION udf_check_palindrom(@str VARCHAR(20))
RETURNS VARCHAR(30) AS
BEGIN
    DECLARE @r_str VARCHAR(20);
    DECLARE @res VARCHAR(30);
    SET @r_str = REVERSE(@str);
    IF @str = @r_str
        SET @res = CONCAT(@str,' is a Palindrom');
    ELSE
        SET @res = CONCAT(@str,' is not a Palindrom');
    RETURN @res;
END;

PRINT dbo.udf_check_palindrom ('nitin');
------------------------------------------------------------

CREATE FUNCTION udf_check_armstrong_2(@n int)
RETURNS VARCHAR(30) AS
BEGIN 
DECLARE @r FLOAT;
DECLARE @sum INT; 
DECLARE @temp INT; 
SET @temp=@n;
SET @sum=0;
WHILE (@n>0)    
BEGIN
SET @r=@n%10;    
SET @sum=@sum+POWER(@temp,3);    
SET @n=@n/10;
END;

IF (@temp=@sum)    
 SET @sum = CONCAT(@n,' is a armstrong');    
else    
 SET @sum = CONCAT(@n , ' is not armstrong');   
RETURN @sum;  
end;

PRINT dbo.udf_check_armstrong_2(153);

-----------------------------------------------------------------
CREATE function armstrong(@num int)
RETURNS VARCHAR(100)
AS
BEGIN
    DECLARE @QT int = @num;
    DECLARE @TEMP INT ;
    DECLARE @sum int = 0;
    DECLARE @result varchar(100);
    WHILE (@QT>0)
    BEGIN
        SET @TEMP = @QT % 10;
        SET @sum = @sum + POWER(@TEMP,3);
        SET @QT = @QT / 10;
    END;
    IF @sum = @num
        SET @result = CONCAT(@NUM,'IS A ARMSTRONG NUMBER');
    ELSE
        SET @result = CONCAT(@NUM,'IS NOT A ARMSTRONG NUMBER');
    RETURN @result;
END;
PRINT DBO.ARMSTRONG(153)

--------------------------------------------------------------------------------------
--Demo 1: Create trigger for insert event
SELECT Name,Color,StandardCost
INTO CessnaBatch2Products
FROM Production.Product

SELECT * FROM CessnaBatch2Products

CREATE TRIGGER TR_INS_CessnaBatch2Products
ON CessnaBatch2Products
AFTER INSERT
AS
BEGIN
    PRINT 'Cessna Batch 2 Product Saved!';
END;

INSERT INTO CessnaBatch2Products VALUES
('Product1','Black',90.99);
INSERT INTO CessnaBatch2Products VALUES
('Product2','Red',22.22);
INSERT INTO CessnaBatch2Products VALUES
('Product3','Black',10.99);

INSERT INTO CessnaBatch2Products VALUES
('Product4','White',333.99),
('Product5','Silver',222.99);

-------------------------------------------------------------
--Demo 1: Create trigger for insert event
SELECT BusinessEntityID,FirstName,LastName
INTO Cessna
FROM Person.Person

SELECT * FROM Cessna


CREATE TRIGGER TR_INS_Cessna
ON Cessna
AFTER UPDATE
AS
BEGIN
    PRINT 'Cessna names Updated!';
END;

UPDATE Cessna 
SET LastName = 'wahed'
WHERE  BusinessEntityID = 285;

UPDATE  Cessna 
SET FirstName = 'Ali'
WHERE  BusinessEntityID = 285;

SELECT * FROM Cessna
------------------------------------------------------------------
CREATE TABLE Cessna_deletelog
(
    DeletedID INT PRIMARY KEY IDENTITY(1,1),
	BusinessEntityID INT,
	FirstName VARCHAR(50),
	LastName VARCHAR(20),
      DeletedDate DATE DEFAULT GETDATE()
);

CREATE TRIGGER TR_DEL_Cessna
ON Cessna
AFTER DELETE
AS
BEGIN
    INSERT INTO Cessna_deletelog
    (BusinessEntityID,FirstName,LastName)
    SELECT BusinessEntityID,FirstName,LastName FROM deleted;
    PRINT 'Record/s deleted and log/s created!';
END;

SELECT * FROM Cessna
SELECT * FROM Cessna_deletelog

DELETE FROM Cessna WHERE FirstName = 'Ali';

-------------------------------------
CREATE TRIGGER TR_INSERT_Cessna
ON Cessna
INSTEAD OF INSERT 
AS
BEGIN
   PRINT 'RECORD INSERTED! HA.HA.HA..!';
   END;

INSERT INTO Cessna VALUES
(293,'Wahed','ali');

INSERT INTO Cessna VALUES
(29333,'Wahed','aliii');
------------------------------------------------------------------





