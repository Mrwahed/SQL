drop table Contacts
 create table Contacts(
      ContactNo int primary key,
      ContactName varchar(20),
	  City varchar(20),
	  CellNo varchar(10),
    )

	USE EntityDB

Create table Cities(
       
	   CityName  varchar,
)