drop table Employees
CREATE TABLE Employees (

          EmployeeID INT  NULL ,
		  FirstName VARCHAR(50),
          LastName VARCHAR(50),
		  Salary Integer,
		  DateOfJoining DATE

);

drop proc InsertEmployee
CREATE PROC InsertEmployee
@empid int,
@fname varchar(30),
@lname varchar(30),
@sal int,
@doj DateTime


as
     insert into Employees values(@empid,@fname,@lname,@sal,@doj)

