--------------DAY 4 ASSIGNMENTS-------

--------1--------
SELECT E.BusinessEntityID,E.JobTitle,E.BirthDate,P.FirstName,P.LastName
FROM HumanResources.Employee AS E
JOIN
Person.Person AS P
ON E.BusinessEntityID = P.BusinessEntityID

--------2-------
SELECT CustomerID,StoreID,TerritoryID,PersonID,FirstName,LastName 
FROM Sales.Customer AS C
JOIN 
Person.Person AS P
ON P.BusinessEntityID = C.PersonID

------3------
SELECT SalesOrderID,SalesQuota,Bonus
FROM Sales.SalesOrderHeader AS SOH
JOIN
Sales.SalesPerson AS SP
ON SP.BusinessEntityID = SOH.SalesPersonID

------4-------
SELECT CatalogDescription,Color,Size,ProductID
FROM Production.ProductModel AS PM
JOIN 
Production.Product AS PP
ON PP.ProductModelID = PM.ProductModelID

-----5--------
SELECT FirstName,LastName,PRP.Name AS [PRODUCTNAME],SOH.PurchaseOrderNumber
FROM Person.Person AS PP
JOIN  Sales.Customer AS SC
ON PP.BusinessEntityID = SC.PersonID
JOIN Sales.SalesOrderHeader AS SOH
ON SC.CustomerID = SOH.CustomerID
JOIN Sales.SalesOrderDetail AS SOD
ON SOH.SalesOrderID = SOD.SalesOrderID
JOIN Production.Product AS PRP
ON SOD.ProductID = PRP.ProductID
WHERE PurchaseOrderNumber IS NOT NULL

-------6-----
SELECT PP.Name AS [Productname],SalesOrderID,SOD.ProductID
FROM Sales.SalesOrderDetail SOD
JOIN Production.Product AS PP
ON SOD.ProductID = PP.ProductID

------7----
SELECT   CR.CurrencyRateID, AverageRate, SalesOrderID,ShipBase
FROM Sales.SalesOrderHeader AS SOH
LEFT OUTER JOIN  Sales.CurrencyRate AS CR
ON SOH.CurrencyRateID = CR.CurrencyRateID
JOIN  Purchasing.ShipMethod AS SM
ON SOH.ShipMethodID = SM.ShipMethodID

------8-------
SELECT SOH.SalesOrderID, SOH.OrderDate,SOH.CustomerID,SOH.SalesOrderNumber,PRD.Name,
CONCAT(PER.FirstName,' ',PER.LastName) AS [CutomerName],
TRT.Name AS [Territory],
SOH.SalesPersonID,SOH.TerritoryID,SOD.ProductID, 
PRD.Name AS [ProdName], PSC.Name AS [Sub Catg.], PCT.Name AS [Catg.],
SOD.OrderQty
FROM Sales.SalesOrderHeader SOH INNER JOIN Sales.SalesOrderDetail SOD
ON SOH.SalesOrderID = SOD.SalesOrderID
INNER JOIN Production.Product PRD
ON SOD.ProductID = PRD.ProductID
LEFT OUTER JOIN Production.ProductSubcategory PSC
ON PSC.ProductSubcategoryID = PRD.ProductSubcategoryID
LEFT OUTER JOIN Production.ProductCategory PCT
ON PSC.ProductCategoryID = PCT.ProductCategoryID
JOIN Sales.Customer CST 
ON SOH.CustomerID = CST.CustomerID
JOIN Person.Person PER 
ON CST.PersonID = PER.BusinessEntityID
JOIN Sales.SalesTerritory TRT
ON SOH.TerritoryID = TRT.TerritoryID


-----9----
SELECT * FROM
(SELECT P.FirstName,P.LastName,BirthDate,Gender,E.BusinessEntityID,DENSE_RANK()OVER(ORDER BY Birthdate DESC ) AS [rank]
FROM Person.Person AS [P] JOIN HumanResources.Employee AS [E]
ON P.BusinessEntityID = E.BusinessEntityID
)w
WHERE [rank] =1

-----10-----

CREATE TABLE tempProductstable(
PRODID INT,
NAME NAME,
COLOR  VARCHAR(50),
STDCOST MONEY,
PRODSUBID INT)

INSERT INTO tempProductstable
    SELECT productId,name,color,standardcost,productsubcategoryid
    FROM Production.Product WHERE Color='Red'
    
    SELECT * FROM tempProductstable


