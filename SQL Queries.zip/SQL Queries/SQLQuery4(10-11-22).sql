SELECT * FROM Person.Person

--DEMO 2:: WHILE LOOP to iterate through table not having seq. data
/*SELECT * FROM RedProducts
DECLARE @TotalRows INT;
SELECT @TotalRows = COUNT(*) FROM RedProducts;
DECLARE @RN INT = 1;
DECLARE @PName VARCHAR(50);
WHILE @RN<=@TotalRows
BEGIN
    SELECT @PName = Name FROM
    (
        SELECT Name, ROW_NUMBER()OVER(ORDER BY Name) AS [RowNum]
         FROM RedProducts
    ) AS T WHERE [RowNum] = @RN;
    PRINT @PName;
    SET @RN += 1;
END;*/

----------------------------------------------------
--DEMO 2:: WHILE LOOP to iterate through table not having seq. data
SELECT * FROM Sales.Currency

DECLARE @TotalRows INT;
SELECT @TotalRows = COUNT(*) FROM Sales.Currency;
DECLARE @RN INT = 1;
DECLARE @PName VARCHAR(50);
DECLARE @CurrencyCode VARCHAR(50)
WHILE @RN<=@TotalRows
BEGIN
    SELECT @PName = Name,@CurrencyCode = CurrencyCode  FROM
    (
        SELECT Name,CurrencyCode ,ROW_NUMBER()OVER(ORDER BY Name) AS [RowNum]
         FROM Sales.Currency
    ) AS T WHERE [RowNum] = @RN;
    PRINT concat(@PName,' - ',@CurrencyCode);
    SET @RN += 1;
END;

-------------------------------------------------------------

/*CREATE PROCEDURE sp_insert_new_trainee
(
    @TraineeID INT,
    @FirstName VARCHAR(20),
    @LastName VARCHAR(20),
    @Gender VARCHAR(1),
    @BatchNo INT,
    @RandomCode INT
)AS
BEGIN
    INSERT INTO CessnaTraineeEmployees VALUES
        (@TraineeID,@FirstName,@LastName,@Gender,@BatchNo,@RandomCode);
    PRINT 'Record Inserted!';
END;



--Extecution
EXECUTE dbo.sp_insert_new_trainee 88888,'Sam','Dcosta','M',2,4;*/

------------------------------------------------------------------------
/*
CREATE a TABLE CessnaTrainees
(TraineeID PK, FirstName, LastName,Gender,BatchNo,RandomCode).
CREATE a SP to insert data in CessnaTrainees table
only if the data meets below requirements
1. FirstName and LastName must not be null
2. Gender must be either M or F
3. BatchNo must be either 1 or 2
4. RandomCode must be between 1 to 10
*/

CREATE TABLE CessnaTrainees
(
    TraineeID INT PRIMARY KEY IDENTITY(101,1),
    FirstName VARCHAR(20),
    LastName VARCHAR(20),
    Gender VARCHAR(1),
    BatchNo INT,
    RandomCode INT
)

CREATE PROCEDURE sp_insert_Cessnatrainee
(
    @TraineeID INT,
    @FirstName VARCHAR(20),
    @LastName VARCHAR(20),
    @Gender VARCHAR(1),
    @BatchNo INT,
    @RandomCode INT
)AS
BEGIN
    INSERT INTO CessnaTrainees VALUES
        (@TraineeID,@FirstName,@LastName,@Gender,@BatchNo,@RandomCode);
    PRINT 'Record Inserted!';
END;



--Extecution
EXECUTE dbo.sp_insert_new_trainee 88888,'Sam','Dcosta','M',2,4;

