/*1. Create a procedure that takes a string parameter.
The input string may be a string or a numeric or NULL value. Convert the string to Integer.
If it cannot be converted write an exception handling section to handle the appropriate error.
If the string is converted to integer print Hello the input integer number of times*/

CREATE PROCEDURE inputString(@io varchar(20))
AS
BEGIN TRY
	SELECT CAST(@io AS INT)
	while(@io > 0)
	BEGIN
	PRINT 'HEllO'
	SET @io = @io - 1
	END
END TRY
BEGIN CATCH
	print @@error
	select ERROR_LINE() as [LineNo],
		   ERROR_MESSAGE() as [ErrMsg],
		   ERROR_NUMBER() as [ErrorCode],
		   ERROR_SEVERITY() as [ErrSev]
END CATCH

EXEC inputString E

/* 2. Create a temp table to represent employees. Design a user defined exception to handle the salary input less than 10000.*/

CREATE TABLE #temp
(
   EmpName VARCHAR(20),
   EmpID INT,
   Salary INT
);
BEGIN TRY
	DECLARE @Salary MONEY;
	SET @Salary = 9999;
	IF @Salary <= 0
		RAISERROR ('Salary Cannot be 0 or Negative!',1,1);
	ELSE IF @Salary > 0 AND @Salary < 10000
		PRINT 'Reasonalble salary to get started with!';
	ELSE IF @Salary = 10000
		PRINT 'Excellent Salary to get started with!';
	
END TRY
BEGIN CATCH
	PRINT ERROR_NUMBER();
	PRINT ERROR_MESSAGE();
END CATCH

/*3. Write a cursor to fetch top 10 costliest products*/

DECLARE @productID INT;
DECLARE @standardcost MONEY;
DECLARE @Costly INT;

DECLARE cur_costliest_products CURSOR
    FOR  SELECT * FROM(SELECT ProductID,StandardCost,ROW_NUMBER()OVER(ORDER BY StandardCost DESC) AS costliest_products
	FROM Production.Product)t WHERE costliest_products   BETWEEN 1 AND 10;
OPEN cur_costliest_products;
--PRINT @@FETCH_STATUS;
FETCH NEXT FROM cur_costliest_products
    INTO @ProductID,@standardcost,@Costly;
WHILE @@FETCH_STATUS = 0
BEGIN
    PRINT '----------------------------------------------------------------';
    PRINT CONCAT('Product ID: ',@ProductID);
    PRINT CONCAT(' standardcost: ',@standardcost);
	 PRINT CONCAT(' costly: ',@Costly);
     PRINT '----------------------------------------------------------------';
    FETCH NEXT FROM cur_costliest_products
        INTO @ProductID,@standardcost,@Costly;
END
CLOSE cur_costliest_products;
DEALLOCATE cur_costliest_products;



/* 4. Document your understanding and possible solutions to Deadlock concept [Hint: You may explore online] */

	Deadlock occurs when two or more tasks permanently block one another because each task has a lock on a resource the
other task is trying to lock. A deadlock is also called a cyclic dependency: in the case of a two-task deadlock,
transaction A has a dependency on transaction B, and transaction B closes the circle by having a dependency on
transaction A.
deadlocks may still occur in databases because:
1. Queries that modify data may block one another.
2. Queries may run under isolation levels that increase blocking.
3. Isolation levels may be specified via client library methods, query hints, or SET statements in Transact-SQL.