CREATE SCHEMA person;
CREATE SCHEMA sales;
CREATE SCHEMA HumanResources;
CREATE SCHEMA production;

CREATE TABLE person.person
(
  PersonID INT PRIMARY KEY IDENTITY(1,1),
  Title VARCHAR(20),
  FirstName VARCHAR(20),
  MiddleName VARCHAR(20),
  LastName VARCHAR(20),
  Gender VARCHAR(1) CHECK(Gender IN('M','F','O','U')),
  ModifiedDate DATE NOT NULL
);

CREATE TABLE sales.Country
(
   CountryID INT PRIMARY KEY IDENTITY(101,1),
   CountryName VARCHAR(10)
);

CREATE TABLE HumanResources.Department
(
    DepartmentID INT PRIMARY KEY IDENTITY(1001,1),
	DepartmentName VARCHAR(20)
);

CREATE TABLE production.ProductionCategory
(
    ProductCategoryID INT PRIMARY KEY IDENTITY(1,1),
	ProductCategoryName VARCHAR(20)
);

CREATE TABLE sales.Territory
(
   TerritoryID INT PRIMARY KEY IDENTITY(101,1),
   TerritoryName VARCHAR(20),
   CountryID INT REFERENCES sales.Country(CountryID)
);

CREATE TABLE sales.Customer
(
  CustomerID INT PRIMARY KEY IDENTITY(101,1),
  PersonID INT REFERENCES person.person(PersonID),
  TerritoryID INT REFERENCES sales.Territory(TerritoryID),
  CustomerGrade VARCHAR(10)
);

CREATE TABLE HumanResources.Employee
(
   EmployeeID INT PRIMARY KEY IDENTITY(1001,1),
   Designation VARCHAR(20) NOT NULL,
   ManegerID VARCHAR(20),
   DateOfJoining DATE NOT NULL,
   DepartmentID INT REFERENCES HumanResources.Department(DepartmentID),
   PersonID INT REFERENCES person.person(PersonID)
);

CREATE TABLE sales.SalesOrderHeader
(
    SalesOrderHeaderID INT PRIMARY KEY IDENTITY(101,1),
	OrderDate DATE NOT NULL,
	CustomerID INT REFERENCES sales.Customer(CustomerID),
	SalesPersonID INT REFERENCES HumanResources.Employee(EmployeeID)
);

CREATE TABLE production.ProductSubCategory
(
  ProductSubCategoryID INT PRIMARY KEY IDENTITY(101,1),
  ProductSubCategoryName VARCHAR(20),
  ProductCategoryID INT REFERENCES production.ProductionCategory(ProductCategoryID)
);

CREATE TABLE production.Product
(
  ProductID INT PRIMARY KEY IDENTITY(1,1),
  ProductName VARCHAR(20),
  ProductCost MONEY,
  QuantityInStock INT,
  ProductSubCategoryID INT REFERENCES production.ProductSubCategory(ProductSubCategoryID)
);

CREATE TABLE sales.SalesOrderDetail
(
  SalesOrderDetailID INT PRIMARY KEY IDENTITY(101,1),
  SalesOrderHeaderID INT REFERENCES sales.SalesOrderHeader(SalesOrderHeaderID),
  ProductID INT REFERENCES production.Product(ProductID),
  OrderQuantity INT
);