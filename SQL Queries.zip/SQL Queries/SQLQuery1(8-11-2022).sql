       -- SUB QUERIES
----get all products costing same as product no.722

SELECT ProductID ,Name,StandardCost,Color FROM Production.Product
WHERE StandardCost=
(
   SELECT StandardCost FROM Production.Product WHERE
  ProductID = 722
  )

---get all the products in Brakes and Chains subcategory

SELECT ProductID,Name,StandardCost,Color,ProductSubCategoryID
FROM Production.Product WHERE ProductSubcategoryID IN
(
   SELECT ProductSubCategoryID FROM Production.ProductSubcategory
   WHERE Name IN ('Brakes','Chains')
)

--GET all the persons who have joined with designation as Design Engineer

SELECT BusinessEntityID,FirstName,LastName
FROM Person.Person WHERE BusinessEntityID IN

(
   SELECT BusinessEntityID FROM HumanResources.Employee
   WHERE JobTitle IN ('Design Engineer')
)
--get all the products that belong to clothing category

 SELECT ProductID ,Name,ProductSubcategoryID
FROM Production.Product
WHERE ProductSubcategoryID IN
(
    SELECT ProductSubcategoryID
    FROM Production.ProductSubcategory
    WHERE ProductCategoryID =

    (
        SELECT ProductCategoryID
        FROM Production.ProductCategory
        WHERE Name = 'Clothing'
    )
)

----get all products costing more than product no 722 and 800

SELECT ProductID,ProductSubcategoryID
FROM Production.Product WHERE
StandardCost > ALL
(
   SELECT StandardCost FROM Production.Product WHERE ProductID IN (722,800)

)

CREATE TABLE MaleEmp
(
   EmployeeID INT,
   Designation VARCHAR(50),
   DOB DATE,
   DOJ DATE,
   Gender VARCHAR(1)
)
INSERT INTO MaleEmp
SELECT BusinessEntityID,JobTitle,BirthDate,HireDate,Gender
FROM HumanResources.Employee WHERE Gender = 'M'

SELECT * FROM MaleEmp

---get all products having standardcot less than avg standardcost for its productsubcategoryig

SELECT * FROM Production.Product AS PP WHERE StandardCost <
(
SELECT AVG(StandardCost) FROM Production.Product WHERE ProductSubcategoryID = PP.ProductSubcategoryID

);

CREATE SYNONYM PRD FOR Production.Product

SELECT * FROM PRD;