create table Departments
(
  DepartmentId int Identity(1,1) Not null,
  DepartmentName varchar(30)
)

select * from Departments

Insert into Departments values('Marketing')
Insert into Departments values('HR')

create table Employees
(
    EmployeeId int Identity(1,1) not null,
	EmployeeName varchar(30),
	Department varchar(30),
	EmailId  varchar(30),
	DateofJoining date 
)
select * from Employees

Insert into Employees values('wahed','HR','wahed@gmail.com','5-11-2019')
Insert into Employees values('sanath','IT','sanath@gmail.com','4-10-2019')